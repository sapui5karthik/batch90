sap.ui.define([
	"zsapprod/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"zsapprod/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/odata/ODataModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function(BaseController, JSONModel, History, formatter, Filter, FilterOperator, ODataModel, MessageToast, MessageBox) {
	"use strict";

	return BaseController.extend("zsapprod.controller.Worklist", {

		formatter: formatter,

		_refersh: function() {
			this.onInit();
		}, // end of _refresh
		onInit: function() {

			var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";

			// ProductSet
			var sapodatamodel = new ODataModel(sapurl);
			var sapjsonmodel = new JSONModel();
			this.graphsjsonmodel = new JSONModel();
			sap.ui.core.BusyIndicator.show(0);
			sapodatamodel.read("/ProductSet", {

				success: function(req, resp) {
					sap.ui.core.BusyIndicator.hide();
					sapjsonmodel.setSizeLimit(1000);

					sapjsonmodel.setData(req.results);
					this.graphsjsonmodel.setData(req.results);
					this.getView().byId("id1").setModel(sapjsonmodel, "sapprod");
					this.getView().byId("iddyncombo").setModel(sapjsonmodel, "c1");

				}.bind(this),
				error: function(msg) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Failed:1000:" + msg);

				}

			}); // end of read
			// SalesOrderSet	
			var sapodatamodel_so = new ODataModel(sapurl);
			var sapjsonmodel_so = new JSONModel();
			var otable2 = this.byId("id2");
			otable2.setBusy(true);
			sapodatamodel_so.read("/SalesOrderSet", {
				success: function(req, resp) {
					otable2.setBusy(false);
					sapjsonmodel_so.setSizeLimit(1000);

					sapjsonmodel_so.setData(req.results);
					this.getView().byId("id2").setModel(sapjsonmodel_so, "sapso");

				}.bind(this),
				error: function(msg) {
					otable2.setBusy(false);
					MessageToast.show("Failed:1000:" + msg);

				}

			}); // end of read
		}, // end of onInit
		_orderbycategory: function() {

			//	/ProductSet?$orderby=Category
			var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";

			var sapodatamodel = new ODataModel(sapurl);
			var sapjsonmodel = new JSONModel();
			sap.ui.core.BusyIndicator.show(0);
			sapodatamodel.read("/ProductSet?$orderby=Category", {

				success: function(req, resp) {
					sap.ui.core.BusyIndicator.hide();
					sapjsonmodel.setSizeLimit(1000);

					sapjsonmodel.setData(req.results);
					this.getView().byId("id1").setModel(sapjsonmodel, "sapprod");

				}.bind(this),
				error: function(msg) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Failed:1000:" + msg);

				}

			}); // end of read

		}, // end of _orderbycategory
		_orderbyPrice: function() {

			//	/ProductSet?$orderby=Price
			var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";

			var sapodatamodel = new ODataModel(sapurl);
			var sapjsonmodel = new JSONModel();
			var otable = this.byId("id1");
			otable.setBusy(true);
			sapodatamodel.read("/ProductSet?$orderby=Price", {

				success: function(req, resp) {
					otable.setBusy(false);
					sapjsonmodel.setSizeLimit(1000);

					sapjsonmodel.setData(req.results);
					this.getView().byId("id1").setModel(sapjsonmodel, "sapprod");

				}.bind(this),
				error: function(msg) {
					otable.setBusy(false);
					MessageToast.show("Failed:1000:" + msg);

				}

			}); // end of read
		}, // end of _orderbyPrice
		_pricelt5: function() {
			var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel = new ODataModel(sapurl);
			var jsonmodel = new JSONModel();
			var filter1 = new Filter("Price", FilterOperator.LT, "5");
			odatamodel.read("/ProductSet", {
				filters: [filter1],
				success: function(req, resp) {
					jsonmodel.setSizeLimit(1000);
					jsonmodel.setData(req.results);
					this.getView().byId("id1").setModel(jsonmodel, "sapprod");
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:3130:" + msg);
				}

			});

		}, // end of _pricelt5

		_pricelt5and10: function() {
			var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel = new ODataModel(sapurl);
			var jsonmodel = new JSONModel();
			var filter1 = new Filter("Price", FilterOperator.BT, "5", "10");
			odatamodel.read("/ProductSet", {
				filters: [filter1],
				success: function(req, resp) {
					jsonmodel.setSizeLimit(1000);
					jsonmodel.setData(req.results);
					this.getView().byId("id1").setModel(jsonmodel, "sapprod");
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:3130:" + msg);
				}

			});
		}, // end of _pricelt5and10

		_categorymice: function() {
			//var filter1 = new Filter("Category",FilterOperator.EQ,"Mice");
		}, // end of _categorymice
		_getcatvalue: function(oevent) {
			var name = this.byId("idinput1").getValue();
			var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel = new ODataModel(sapurl);
			var jsonmodel = new JSONModel();
			var filter1 = new Filter("Category", FilterOperator.Contains, name);
			var otable = this.byId("id1");
			otable.setBusy(true);
			odatamodel.read("/ProductSet", {
				filters: [filter1],
				success: function(req, resp) {
					otable.setBusy(false);
					jsonmodel.setSizeLimit(1000);
					jsonmodel.setData(req.results);
					this.getView().byId("id1").setModel(jsonmodel, "sapprod");
				}.bind(this),
				error: function(msg) {
					MessageToast.show("Failed:3130:" + msg);
				}

			});

		}, // end of _getcatvalue
		_staticSelect: function(oevent) {

			//how do you get the reference of the Control in the Controller?
			//	this.byId("id12121");
			//	oevent.getSource();
			//	oevent.getParameter("selectedItem");
			//this.byId("id12121").mProperties.selectedKey;	
			//this.byId("id12121").getSelectedKey();
			var key = oevent.getSource().getSelectedKey();
			//oevent.getParameter("selectedItem").getKey();
			if (key === "k1") {
				this._orderbycategory();
			}
			if (key === "k2") {
				this._orderbyPrice();
			}
			if (key === "k0") {
				this._refersh();
			}
			if (key === "k3") {
				this._pricelt5();
			}
		}, // end of _staticSelect

		_dynacombo: function(oevent) {
			var pid = oevent.getSource().getValue();

			var url = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			var odatamodel = new ODataModel(url);
			var jsonmodel = new JSONModel();
			var filter1 = new Filter("ProductID", FilterOperator.EQ, pid);
			sap.ui.core.BusyIndicator.show(0);
			odatamodel.read("/ProductSet", {
				filters: [filter1],
				success: function(req, resp) {
					sap.ui.core.BusyIndicator.hide();
					jsonmodel.setData(req.results);
					this.getView().byId("id1").setModel(jsonmodel, "sapprod");
				}.bind(this),
				error: function(msg) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show("Failed:20202:" + msg);
				}
			});

		}, // end of _dynacombo

		_onRowPress: function(oevent) {

			var bc = oevent.getSource().getBindingContext("sapprod");

			var pid = bc.getProperty("ProductID");
			var price = bc.getProperty("Price");
			if (oevent.getParameter("selected")) {
				MessageBox.success(pid + "\n" + price, {
					title: "SAP Product Details"
				});
			}
			//MessageBox.warning(pid+"\n"+price,{title: "SAP Product Details"});
			//MessageBox.information(pid+"\n"+price,{title: "SAP Product Details"});
			//MessageBox.confirm(pid+"\n"+price,{title: "SAP Product Details"});
			//MessageBox.alert(pid+"\n"+price,{title: "SAP Product Details"});

			//	MessageToast.show(pid + "------SRINU----------" + price);
		}, // end of _onRowPress

		_openHelloWorld: function(oevent) {
			if (oevent.getParameter("selected")) {

				if (!this.hello) {
					this.hello = sap.ui.xmlfragment(this.getView().getId(), "zsapprod.fragments.HelloWorld", this);
					this.getView().addDependent(this.hello);
				}

				this.hello.open();

			}
		}, // end of _openHelloWorld
		_closehello: function() {
			this.hello.close();
			this.byId("idchk1").setSelected(false);
		}, //end of _closehello
		_graph: function(oevent) {

			var key = oevent.getSource().getSelectedKey();
			if (key === "k1") {

				// open the LineGraph fragment

				if (!this.line1) {
					this.line1 = sap.ui.xmlfragment(this.getView().getId(), "zsapprod.fragments.LineGraph", this);
					this.getView().addDependent(this.line1);
				}
				this.line1.open();
				// Show the Line Graph
				var oVizFrame = this.getView().byId("idVizFrame").setModel(this.graphsjsonmodel, "l1");
				oVizFrame.setVizProperties({
					plotArea: {
						dataLabel: {

							visible: true
						}
					},
					valueAxis: {

						title: {
							visible: true
						}
					},
					categoryAxis: {
						title: {
							visible: true
						}
					},
					title: {
						visible: true,
						text: 'ProductID vs Price'
					}
				});

			}
			if (key === "k2") {
				// open Bar Graph
				if (!this.bar1) {
					this.bar1 = sap.ui.xmlfragment(this.getView().getId(), "zsapprod.fragments.BarGraph", this);
					this.getView().addDependent(this.bar1);
				}
				this.bar1.open();
				// Show the bar Graph
				var oVizFrame1 = this.getView().byId("idVizFrame1").setModel(this.graphsjsonmodel, "l1");
				oVizFrame1.setVizProperties({
					plotArea: {
						dataLabel: {

							visible: true
						}
					},
					valueAxis: {

						title: {
							visible: true
						}
					},
					categoryAxis: {
						title: {
							visible: true
						}
					},
					title: {
						visible: true,
						text: 'ProductID vs Price'
					}
				});

			}
			if (key === "k3") {

			}
			if (key === "k4") {

			}
			if (key === "k5") {

			}
		}, // end of _graph
		_closeLineGraph: function() {
			this.line1.close();
		}, // end of _closeLineGraph
		_closeBarGraph: function() {
			this.bar1.close();
		}, // end of _closeBarGraph

_gotoobjectview : function(oevent){
	this.oRouter = sap.ui.core.UIComponent.getRouterFor(this);
	//this.oRouter.navTo("",{},true);
	this.oRouter.navTo("object",{
		from : "worklist",
		to : "object",
		ProductID : oevent.getSource().getBindingContext("sapprod").getProperty("ProductID")
	},true);
	debugger;
	
}, // end of _gotoobjectview



		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		_onInit: function() {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			this._oTable = oTable;
			// keeps the search state
			this._oTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("saveAsTileTitle", this.getResourceBundle().getText("worklistViewTitle")),
				shareOnJamTitle: this.getResourceBundle().getText("worklistTitle"),
				shareSendEmailSubject: this.getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getResourceBundle().getText("shareSendEmailWorklistMessage", [location.href]),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onShareInJamPress: function() {
			var oViewModel = this.getModel("worklistView"),
				oShareDialog = sap.ui.getCore().createComponent({
					name: "sap.collaboration.components.fiori.sharing.dialog",
					settings: {
						object: {
							id: location.href,
							share: oViewModel.getProperty("/shareOnJamTitle")
						}
					}
				});
			oShareDialog.open();
		},

		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");

				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("Price", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			this._oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("ProductID")
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oViewModel = this.getModel("worklistView");
			this._oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		}

	});
});