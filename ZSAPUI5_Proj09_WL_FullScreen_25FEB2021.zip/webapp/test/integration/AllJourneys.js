jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"zsapprod/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"zsapprod/test/integration/pages/Worklist",
		"zsapprod/test/integration/pages/Object",
		"zsapprod/test/integration/pages/NotFound",
		"zsapprod/test/integration/pages/Browser",
		"zsapprod/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zsapprod.view."
	});

	sap.ui.require([
		"zsapprod/test/integration/WorklistJourney",
		"zsapprod/test/integration/ObjectJourney",
		"zsapprod/test/integration/NavigationJourney",
		"zsapprod/test/integration/NotFoundJourney",
		"zsapprod/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});