sap.ui.define([
	] , function () {
		"use strict";

		return {

				srinu : function(a){
					if(!a){
						return "";
					}
					return parseFloat(a).toFixed(6);
				},
				p1 : function(p2){
					if(!p2){
						return "";
					}
					
					return parseFloat(p2).toFixed(2);
				},
				offer1 : function(price1){
					if(!price1){
						return "";
					}
					if(price1 >= 1000.00 && price1 <= 2000.00){
						return parseFloat(price1-100.00).toFixed(2);
					}
					if(price1 >= 2000.00 && price1 <= 3000.00){
						return parseFloat(price1-200.00).toFixed(2);
					}
					if(price1 >= 3000.00){
						return parseFloat(price1-500.00).toFixed(2);
					}
					else {
						return "0";
					}
					
				}, 
				color1 : function(c1){
					if(c1 <= 1000.00){
						return 'Success';
					}
					if(c1 >= 1000.00 && c1 <= 2000.00){
						return 'Warning';
					}
					if(c1 >= 2000.00 ){
						return 'Error';
					}
				},
				date1 : function(d1){
					if(!d1){
						return "";
					}
					return new Date(d1).toDateString();
				},
				date2 : function(d2){
				var d3 = new Date(d2);
				var x = {
					weekday : "long",
					year : "numeric",
					month : "short",
					day: "numeric"
				};
				
				
				return d3.toLocaleDateString("te",x);
					
				},
			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			numberUnit : function (sValue) {
				if (!sValue) {
					return "";
				}
				return parseFloat(sValue).toFixed(2);
			}

		};

	}
);