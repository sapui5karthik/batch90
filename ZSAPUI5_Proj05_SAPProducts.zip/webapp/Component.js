sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZSAPUI5_Proj05_SAPProductsZSAPUI5_Proj05_SAPProducts/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("ZSAPUI5_Proj05_SAPProductsZSAPUI5_Proj05_SAPProducts.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			var empdata = {
				"empname" : "Srinu"
			};
			
			var globaljsonmodel = new sap.ui.model.json.JSONModel();
			globaljsonmodel.setData(empdata);
			sap.ui.getCore().setModel(globaljsonmodel,"global");
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});