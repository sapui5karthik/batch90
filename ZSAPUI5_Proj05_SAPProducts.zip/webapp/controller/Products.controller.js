sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/ODataModel",
	"sap/m/MessageToast"
], function(Controller,JSONModel,ODataModel,MessageToast) {
	"use strict";

	return Controller.extend("ZSAPUI5_Proj05_SAPProductsZSAPUI5_Proj05_SAPProducts.controller.Products", {
			
			_refersh : function(){
				this.onInit();
			}, // end of _refresh
			onInit : function(){
				
				var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
			
			
			// ProductSet
				var sapodatamodel = new ODataModel(sapurl);
				var sapjsonmodel = new JSONModel();
				sap.ui.core.BusyIndicator.show(0);
					sapodatamodel.read("/ProductSet",{
						
					success : function(req,resp){
						sap.ui.core.BusyIndicator.hide();
						sapjsonmodel.setSizeLimit(1000);
						
						sapjsonmodel.setData(req.results);
						this.getView().byId("id1").setModel(sapjsonmodel,"sapprod");
						
					}.bind(this),
					error : function(msg){
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Failed:1000:" + msg);
						
					}
						
					}); // end of read
			// SalesOrderSet	
				var sapodatamodel_so = new ODataModel(sapurl);
				var sapjsonmodel_so = new JSONModel();
				var otable2 = this.byId("id2");
				otable2.setBusy(true);
				sapodatamodel_so.read("/SalesOrderSet",{
					success : function(req,resp){
						otable2.setBusy(false);
						sapjsonmodel_so.setSizeLimit(1000);
						
						sapjsonmodel_so.setData(req.results);
						this.getView().byId("id2").setModel(sapjsonmodel_so,"sapso");
						
					}.bind(this),
					error : function(msg){
							otable2.setBusy(false);
						MessageToast.show("Failed:1000:" + msg);
						
					}
						
					}); // end of read
			}, // end of onInit
			_orderbycategory : function(){
				
			//	/ProductSet?$orderby=Category
				var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		
				var sapodatamodel = new ODataModel(sapurl);
				var sapjsonmodel = new JSONModel();
				sap.ui.core.BusyIndicator.show(0);
					sapodatamodel.read("/ProductSet?$orderby=Category",{
						
					success : function(req,resp){
						sap.ui.core.BusyIndicator.hide();
						sapjsonmodel.setSizeLimit(1000);
						
						sapjsonmodel.setData(req.results);
						this.getView().byId("id1").setModel(sapjsonmodel,"sapprod");
						
					}.bind(this),
					error : function(msg){
						sap.ui.core.BusyIndicator.hide();
						MessageToast.show("Failed:1000:" + msg);
						
					}
						
					}); // end of read
				
				
			}, // end of _orderbycategory
			_orderbyPrice : function(){
			
					//	/ProductSet?$orderby=Price
				var sapurl = "/sap/opu/odata/iwbep/GWSAMPLE_BASIC/";
		
				var sapodatamodel = new ODataModel(sapurl);
				var sapjsonmodel = new JSONModel();
				var otable = this.byId("id1");
				otable.setBusy(true);
					sapodatamodel.read("/ProductSet?$orderby=Price",{
						
					success : function(req,resp){
						otable.setBusy(false);
						sapjsonmodel.setSizeLimit(1000);
						
						sapjsonmodel.setData(req.results);
						this.getView().byId("id1").setModel(sapjsonmodel,"sapprod");
						
					}.bind(this),
					error : function(msg){
						otable.setBusy(false);
						MessageToast.show("Failed:1000:" + msg);
						
					}
						
					}); // end of read
			}, // end of _orderbyPrice
			
			
			
	});
});







