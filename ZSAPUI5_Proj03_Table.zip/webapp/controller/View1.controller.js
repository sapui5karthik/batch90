sap.ui.define(["sap/ui/core/mvc/Controller",
"/sap/ui/model/json/JSONModel"], function(Controller, JSONModel) {
	"use strict";
	return Controller.extend("ZSAPUI5_Proj03_TableZSAPUI5_Proj03_Table.controller.View1", {
		_getdata: function() {},
		onInit: function() {
			var vmaxempdata = {
				"empdata": [{
						"EMPID": 100,
						"EMPNAME": "Anil",
						"EMPDES": "Sr.ABAper",
						"MaritalStatus": "Married",
						"gender": "http://www.pngplay.com/wp-content/uploads/2/Cartoon-Man-Background-PNG-Image.png"
					}, {
						"EMPID": 101,
						"EMPNAME": "Babu",
						"EMPDES": "Sr.Lead",
						"MaritalStatus": "Single",
						"gender": "http://www.pngplay.com/wp-content/uploads/2/Cartoon-Man-Background-PNG-Image.png"
					}, {
						"EMPID": 102,
						"EMPNAME": "Chiru",
						"EMPDES": "Sr.Manager",
						"MaritalStatus": "Married",
						"gender": "http://www.pngplay.com/wp-content/uploads/2/Cartoon-Man-Background-PNG-Image.png"
					}, {
						"EMPID": 103,
						"EMPNAME": "Dheeraj",
						"EMPDES": "AccountManager",
						"MaritalStatus": "Single",
						"gender": "http://www.pngplay.com/wp-content/uploads/2/Cartoon-Man-Background-PNG-Image.png"
					}, {
						"EMPID": 104,
						"EMPNAME": "Srinu",
						"EMPDES": "UI5 Developer",
						"MaritalStatus": "Single",
						"gender": "http://www.pngplay.com/wp-content/uploads/2/Cartoon-Man-Background-PNG-Image.png"
					}

				]
			};
			var jsonmodel1 = new JSONModel();
			jsonmodel1.setData(vmaxempdata);
			this.getView().setModel(jsonmodel1, "vmaxemp");
		}
	});
});